# EntreDos — MVP de chat anónimo

Prototipo inicial separado del marketplace. Incluye interfaz Next.js y un servidor Socket.IO para emparejamiento aleatorio por modo.

## Requisitos
- Node.js 18.17+ (recomendado Node 20 LTS)
- npm
- Conexión a internet durante la instalación de dependencias

## Ejecutar en desarrollo

1. Descomprime la carpeta `entre-dos-chat` en una ubicación independiente.
2. Abre una terminal dentro de esa carpeta.
3. Instala dependencias:

   ```bash
   npm install
   ```

4. Inicia la web y el servidor de chat:

   ```bash
   npm run dev
   ```

5. Abre http://localhost:3000 en el navegador.
6. Para probar el emparejamiento, abre la web en dos ventanas o navegadores diferentes y entra en el mismo modo.

La web corre en el puerto 3000 y el servidor Socket.IO en el 3001. Si necesitas cambiar la URL del chat, define `NEXT_PUBLIC_CHAT_URL` antes de iniciar Next.js. Para permitir otro origen en el servidor, define `WEB_ORIGIN`.

## Qué incluye
- Tres modos: casual, romántico respetuoso y conversación profunda.
- Emparejamiento aleatorio por modo y botón para buscar otra persona.
- Mensajes solo en memoria; no hay base de datos ni historial persistente.
- Límite de 500 caracteres, límite básico de frecuencia y bloqueo de enlaces.
- Controles de interfaz para reportar y terminar la conversación.
- Diseño adaptable a escritorio y móvil.

## Importante antes de publicar
Esto es un MVP de desarrollo, no una plataforma lista para público real. El aviso de edad es una declaración del usuario, no verificación de edad. Antes del lanzamiento público hacen falta una estrategia apropiada de verificación de edad, moderación y gestión de reportes, protección contra bots/abuso, política de privacidad, términos, controles de seguridad, pruebas de carga y configuración HTTPS/orígenes. Los reportes actuales solo viven en memoria y se imprimen en la consola; se pierden al reiniciar el servidor. No se guardan los mensajes ni se adjunta evidencia al reporte.

Los anuncios todavía no están integrados. Se recomienda incorporarlos después de estabilizar el chat y revisar las políticas de la red publicitaria elegida.
