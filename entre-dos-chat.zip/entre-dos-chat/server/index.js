const { createServer } = require('node:http');
const { Server } = require('socket.io');

const PORT = Number(process.env.CHAT_PORT || 3001);
const allowedModes = new Set(['casual', 'romantic', 'deep']);
const httpServer = createServer((req, res) => {
  res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify({ service: 'EntreDos chat', status: 'ok' }));
});
const io = new Server(httpServer, {
  cors: { origin: process.env.WEB_ORIGIN ? process.env.WEB_ORIGIN.split(',') : ['http://localhost:3000', 'http://127.0.0.1:3000'], methods: ['GET', 'POST'] },
  maxHttpBufferSize: 10_000,
});

const queues = new Map([['casual', []], ['romantic', []], ['deep', []]]);
const partnerBySocket = new Map();
const modeBySocket = new Map();
const lastMessageAt = new Map();
const reportsThisProcess = [];
const blockedBySocket = new Map();

function removeFromQueues(socketId) {
  for (const queue of queues.values()) {
    const index = queue.indexOf(socketId);
    if (index !== -1) queue.splice(index, 1);
  }
}
function disconnectPair(socketId, notifyPartner = true) {
  const partnerId = partnerBySocket.get(socketId);
  partnerBySocket.delete(socketId);
  if (partnerId) {
    partnerBySocket.delete(partnerId);
    const partnerSocket = io.sockets.sockets.get(partnerId);
    if (partnerSocket && notifyPartner) partnerSocket.emit('partner_left');
  }
}
function leaveEverything(socketId, notifyPartner = true) {
  removeFromQueues(socketId);
  disconnectPair(socketId, notifyPartner);
  modeBySocket.delete(socketId);
}
function findPartner(socket, mode) {
  const queue = queues.get(mode);
  if (!queue) return;
  removeFromQueues(socket.id);
  const deferred = [];
  while (queue.length) {
    const candidateId = queue.shift();
    if (candidateId === socket.id) continue;
    const candidate = io.sockets.sockets.get(candidateId);
    if (!candidate || partnerBySocket.has(candidateId)) continue;
    const blockedByCurrent = blockedBySocket.get(socket.id);
    const blockedByCandidate = blockedBySocket.get(candidateId);
    if (blockedByCurrent?.has(candidateId) || blockedByCandidate?.has(socket.id)) { deferred.push(candidateId); continue; }
    partnerBySocket.set(socket.id, candidateId);
    partnerBySocket.set(candidateId, socket.id);
    modeBySocket.set(socket.id, mode);
    modeBySocket.set(candidateId, mode);
    socket.emit('match_found');
    candidate.emit('match_found');
    for (const deferredId of deferred) queue.push(deferredId);
    return;
  }
  for (const deferredId of deferred) queue.push(deferredId);
  queue.push(socket.id);
  modeBySocket.set(socket.id, mode);
  socket.emit('waiting');
}

io.on('connection', socket => {
  socket.on('join_queue', payload => {
    const mode = payload && allowedModes.has(payload.mode) ? payload.mode : 'casual';
    leaveEverything(socket.id);
    findPartner(socket, mode);
  });

  socket.on('next_person', payload => {
    const requestedMode = payload && allowedModes.has(payload.mode) ? payload.mode : modeBySocket.get(socket.id) || 'casual';
    leaveEverything(socket.id);
    findPartner(socket, requestedMode);
  });

  socket.on('chat_message', payload => {
    const text = typeof payload?.text === 'string' ? payload.text.trim() : '';
    if (!text || text.length > 500) return socket.emit('chat_error', 'El mensaje debe tener entre 1 y 500 caracteres.');
    if (/(https?:\/\/|www\.|[\w.-]+\.(com|net|org|gg|io|mx)\b)/i.test(text)) return socket.emit('chat_error', 'Por seguridad, no se permiten enlaces en el chat.');
    const now = Date.now();
    const previous = lastMessageAt.get(socket.id) || 0;
    if (now - previous < 700) return socket.emit('chat_error', 'Espera un momento antes de enviar otro mensaje.');
    const partnerId = partnerBySocket.get(socket.id);
    if (!partnerId) return socket.emit('chat_error', 'No tienes una conversación activa.');
    const partner = io.sockets.sockets.get(partnerId);
    if (!partner) { disconnectPair(socket.id); return socket.emit('partner_left'); }
    lastMessageAt.set(socket.id, now);
    partner.emit('incoming_message', { text, time: new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }) });
  });

  socket.on('report_user', payload => {
    const reason = typeof payload?.reason === 'string' ? payload.reason.slice(0, 80) : 'Sin motivo especificado';
    const report = { reportedAt: new Date().toISOString(), reporterSession: socket.id, reportedSession: partnerBySocket.get(socket.id) || null, reason };
    reportsThisProcess.push(report);
    // MVP: reportes solo en memoria y en consola. No se guarda el contenido de los mensajes.
    console.warn('[EntreDos report]', JSON.stringify(report));
  });

  socket.on('block_user', () => {
    const partnerId = partnerBySocket.get(socket.id);
    if (partnerId) {
      if (!blockedBySocket.has(socket.id)) blockedBySocket.set(socket.id, new Set());
      blockedBySocket.get(socket.id).add(partnerId);
      const partner = io.sockets.sockets.get(partnerId);
      if (partner) partner.emit('partner_left');
    }
    leaveEverything(socket.id, false);
  });

  socket.on('leave_chat', () => leaveEverything(socket.id));
  socket.on('disconnect', () => {
    leaveEverything(socket.id);
    lastMessageAt.delete(socket.id);
    blockedBySocket.delete(socket.id);
  });
});

httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`EntreDos chat server listening on port ${PORT}`);
});
