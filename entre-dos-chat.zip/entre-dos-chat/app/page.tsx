'use client';

import { FormEvent, useEffect, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';

type Mode = 'casual' | 'romantic' | 'deep';
type ChatMessage = { id: string; text: string; mine: boolean; time: string };
type MatchState = 'idle' | 'searching' | 'matched' | 'disconnected';

const SOCKET_URL = process.env.NEXT_PUBLIC_CHAT_URL || 'http://localhost:3001';
const modes: { id: Mode; title: string; description: string; icon: string }[] = [
  { id: 'casual', title: 'Charla casual', description: 'Conversa sin presión', icon: '☕' },
  { id: 'romantic', title: 'Coqueteo respetuoso', description: 'Conoce a alguien especial', icon: '♡' },
  { id: 'deep', title: 'Conversación profunda', description: 'Habla de lo que importa', icon: '✦' },
];
const starters = [
  '¿Qué canción nunca te cansas de escuchar?',
  '¿Qué pequeño detalle te mejora el día?',
  '¿Preferirías conocer el futuro o cambiar una decisión del pasado?',
  '¿Qué tema podrías hablar durante horas?',
  '¿Qué lugar te gustaría conocer algún día?',
  '¿Qué hace que una conversación se sienta especial?',
  '¿Qué opinión tuya suele sorprender a la gente?',
  '¿Qué te gustaría aprender si tuvieras tiempo ilimitado?',
];

export default function Home() {
  const [acceptedAge, setAcceptedAge] = useState(false);
  const [ageChecked, setAgeChecked] = useState(false);
  const [mode, setMode] = useState<Mode>('casual');
  const [matchState, setMatchState] = useState<MatchState>('idle');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [partner, setPartner] = useState('Persona anónima');
  const [notice, setNotice] = useState('');
  const [starter, setStarter] = useState(starters[0]);
  const [socketReady, setSocketReady] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState('Acoso o insultos');
  const socketRef = useRef<Socket | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const socket = io(SOCKET_URL, { autoConnect: false, transports: ['websocket', 'polling'] });
    socketRef.current = socket;
    socket.on('connect', () => { setSocketReady(true); setNotice(''); });
    socket.on('connect_error', () => { setSocketReady(false); setNotice('No se pudo conectar al servidor de chat. Revisa que esté encendido.'); });
    socket.on('match_found', () => {
      setMatchState('matched');
      setMessages([]);
      setPartner('Persona anónima');
      setNotice('Conexión encontrada. Saluda cuando quieras.');
    });
    socket.on('waiting', () => { setMatchState('searching'); setNotice('Buscando a alguien para conversar…'); });
    socket.on('incoming_message', (payload: { text: string; time: string }) => {
      setMessages(prev => [...prev, { id: `${Date.now()}-${Math.random()}`, text: payload.text, mine: false, time: payload.time }]);
      setNotice('');
    });
    socket.on('partner_left', () => {
      setMatchState('disconnected');
      setNotice('La otra persona terminó la conversación. Puedes buscar a alguien más.');
    });
    socket.on('chat_error', (message: string) => setNotice(message));
    socket.connect();
    return () => { socket.disconnect(); socketRef.current = null; };
  }, []);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  function startChat() {
    if (!acceptedAge) { setNotice('Confirma que tienes 18 años o más para continuar.'); return; }
    if (!socketRef.current?.connected) { setNotice('El servidor aún no está conectado. Inicia el proyecto siguiendo el README.'); return; }
    setMessages([]);
    setMatchState('searching');
    setNotice('Buscando a alguien para conversar…');
    socketRef.current.emit('join_queue', { mode });
  }

  function nextPerson() {
    socketRef.current?.emit('next_person', { mode });
    setMessages([]);
    setMatchState('searching');
    setNotice('Buscando a alguien nuevo…');
  }

  function sendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const text = draft.trim();
    if (!text || matchState !== 'matched') return;
    if (text.length > 500) { setNotice('El mensaje no puede superar los 500 caracteres.'); return; }
    if (/(https?:\/\/|www\.|[\w.-]+\.(com|net|org|gg|io|mx)\b)/i.test(text)) {
      setNotice('Por seguridad, no se permiten enlaces en el chat.');
      return;
    }
    socketRef.current?.emit('chat_message', { text });
    setMessages(prev => [...prev, { id: `${Date.now()}-${Math.random()}`, text, mine: true, time: new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }) }]);
    setDraft('');
    setNotice('');
  }

  function endChat() {
    socketRef.current?.emit('leave_chat');
    setMatchState('idle');
    setMessages([]);
    setNotice('Conversación terminada. Los mensajes no se guardan en un historial.');
  }

  function reportUser() {
    socketRef.current?.emit('report_user', { reason: reportReason });
    socketRef.current?.emit('leave_chat');
    setReportOpen(false);
    setMatchState('idle');
    setMessages([]);
    setNotice('Reporte enviado en esta sesión. La conversación terminó.');
  }

  function useStarter() {
    const next = starters[Math.floor(Math.random() * starters.length)];
    setStarter(next);
    setDraft(next);
  }

  const activeMode = modes.find(item => item.id === mode)!;

  return (
    <main className="site-shell">
      <header className="topbar">
        <a className="brand" href="#inicio" aria-label="EntreDos inicio"><span className="brand-mark">e</span><span>entre<span className="brand-light">dos</span></span></a>
        <div className="topbar-right"><span className={`status-dot ${socketReady ? 'online' : ''}`} /> <span>{socketReady ? 'Servidor conectado' : 'Conectando…'}</span><a className="rules-link" href="#reglas">Reglas</a></div>
      </header>

      {!acceptedAge ? (
        <section className="age-screen" id="inicio">
          <div className="age-card">
            <div className="hero-orbit"><span>♡</span><i /><b /></div>
            <p className="eyebrow">UN ESPACIO PARA CONOCER A ALGUIEN</p>
            <h1>A veces, una buena conversación lo cambia todo.</h1>
            <p className="hero-copy">Conoce a alguien nuevo de forma anónima. Sin perfiles que mantener ni presión por impresionar.</p>
            <div className="age-warning"><span>18+</span><span>Este espacio está pensado exclusivamente para personas adultas.</span></div>
            <label className="age-check"><input type="checkbox" checked={ageChecked} onChange={e => setAgeChecked(e.target.checked)} /><span>Confirmo que tengo 18 años o más y acepto las reglas de convivencia.</span></label>
            <button className="primary-button full" onClick={() => { if (ageChecked) { setAcceptedAge(true); setNotice(''); } else setNotice('Marca la casilla para confirmar que eres mayor de edad.'); }}>Entrar a EntreDos <span>→</span></button>
            {notice && <p className="inline-notice">{notice}</p>}
            <p className="fine-print">La confirmación de edad no sustituye una verificación de edad robusta si la ley o la plataforma la requieren.</p>
          </div>
        </section>
      ) : (
        <div className="app-layout" id="inicio">
          <aside className="sidebar">
            <div className="sidebar-intro"><p className="eyebrow">TU MOMENTO</p><h2>¿De qué te gustaría hablar?</h2><p>Elige el ambiente. Lo demás empieza con un hola.</p></div>
            <div className="mode-list" role="radiogroup" aria-label="Modo de conversación">
              {modes.map(item => <button key={item.id} className={`mode-option ${mode === item.id ? 'selected' : ''}`} onClick={() => setMode(item.id)} aria-pressed={mode === item.id}><span className="mode-icon">{item.icon}</span><span className="mode-text"><strong>{item.title}</strong><small>{item.description}</small></span><span className="mode-radio" /></button>)}
            </div>
            <div className="prompt-card"><div className="prompt-top"><span className="sparkle">✦</span><span>ROMPE EL HIELO</span></div><p>“{starter}”</p><button className="text-button" onClick={useStarter}>Usar esta pregunta <span>↗</span></button><button className="shuffle-button" onClick={() => setStarter(starters[Math.floor(Math.random() * starters.length)])} aria-label="Otra pregunta">⟳</button></div>
            <div className="privacy-note"><span className="lock-icon">⌑</span><div><strong>Privacidad por diseño</strong><p>Sin fotos, perfiles públicos ni historial de chats.</p></div></div>
          </aside>

          <section className="chat-column" aria-label="Chat anónimo">
            <div className="chat-header"><div className="chat-heading"><div className="avatar">{matchState === 'matched' ? '✦' : '♡'}</div><div><h2>{matchState === 'matched' ? partner : matchState === 'searching' ? 'Buscando conexión' : 'Tu próxima conversación'}</h2><p><span className={`tiny-dot ${matchState === 'matched' ? 'online' : ''}`} />{matchState === 'matched' ? `En línea · ${activeMode.title}` : matchState === 'searching' ? 'Un momento, por favor' : 'Anónimo y sin presión'}</p></div></div><div className="chat-actions">{matchState === 'matched' && <><button className="icon-button" title="Reportar usuario" onClick={() => setReportOpen(true)}>⚑</button><button className="icon-button" title="Bloquear y salir" onClick={() => { socketRef.current?.emit('block_user'); setMatchState('idle'); setMessages([]); setNotice('Usuario bloqueado durante esta sesión.'); }}>⊘</button><button className="icon-button" title="Terminar conversación" onClick={endChat}>×</button></>}</div></div>
            <div className="messages-area">
              {matchState === 'matched' ? <>
                <div className="conversation-badge"><span>✦</span> CONVERSACIÓN ANÓNIMA <span>✦</span></div>
                <div className="system-message">Ya están conectados. Sé tú mismo y trata a la otra persona con respeto.</div>
                {messages.map(message => <div key={message.id} className={`message-row ${message.mine ? 'mine' : 'theirs'}`}><div className="message-bubble"><p>{message.text}</p><time>{message.time}</time></div></div>)}
                <div ref={bottomRef} />
              </> : <div className="empty-state"><div className={`empty-art ${matchState === 'searching' ? 'searching' : ''}`}><span className="art-star star-one">✦</span><span className="art-heart">♡</span><span className="art-star star-two">✧</span><span className="art-orbit" /></div><p className="eyebrow">{matchState === 'searching' ? 'ENCUENTRA TU CONEXIÓN' : 'CADA PERSONA ES UNA HISTORIA'}</p><h2>{matchState === 'searching' ? 'Buscando a alguien como tú…' : matchState === 'disconnected' ? 'La conversación terminó' : 'Una conversación puede empezar aquí.'}</h2><p className="empty-copy">{matchState === 'searching' ? 'Te conectaremos cuando haya otra persona disponible en este modo.' : 'Cuando estés listo, encuentra a alguien nuevo y descubre de qué pueden hablar.'}</p>{matchState === 'searching' && <div className="loading-dots"><i /><i /><i /></div>}</div>}
            </div>
            {matchState === 'matched' ? <form className="composer" onSubmit={sendMessage}><div className="composer-tip">Mantén la conversación amable. No compartas datos personales.</div><div className="composer-row"><input value={draft} onChange={e => setDraft(e.target.value)} placeholder="Escribe algo bonito…" maxLength={500} aria-label="Escribe un mensaje"/><span className="char-count">{draft.length}/500</span><button className="send-button" type="submit" disabled={!draft.trim()} aria-label="Enviar mensaje">↑</button></div><div className="composer-bottom"><span>↳ Los enlaces no están permitidos</span><button type="button" className="text-button" onClick={useStarter}>Necesito una idea ✦</button></div></form> : <div className="chat-cta"><button className="primary-button" onClick={startChat} disabled={matchState === 'searching' || !socketReady}>{matchState === 'searching' ? <><span className="button-spinner" /> Buscando…</> : <>{matchState === 'disconnected' ? 'Encontrar otra persona' : 'Encontrar conversación'} <span>→</span></>}</button><p>Gratis · Anónimo · Solo texto</p></div>}
            {matchState === 'matched' && <div className="next-bar"><span>¿No fluye la conversación?</span><button onClick={nextPerson}>Conocer a otra persona <span>→</span></button></div>}
            {notice && <p className="notice-bar" role="status">{notice}<button onClick={() => setNotice('')} aria-label="Cerrar aviso">×</button></p>}
          </section>
          <aside className="right-rail"><div className="rail-card mood-card"><span className="rail-icon">✧</span><p className="eyebrow">UN PEQUEÑO RECORDATORIO</p><h3>No necesitas tener la frase perfecta.</h3><p>La curiosidad sincera suele ser el mejor comienzo.</p><div className="mood-line"><span /><span /><span /><span /><span /></div></div><div className="rail-card rules-card" id="reglas"><h3>Un lugar más amable</h3><ul><li><span>✓</span> Respeta los límites</li><li><span>✓</span> No compartas datos privados</li><li><span>✓</span> Sin contenido explícito</li><li><span>✓</span> Sin spam ni enlaces</li></ul><p>Si alguien cruza la línea, puedes reportarlo.</p></div><div className="rail-footer"><span>entre<span className="brand-light">dos</span> © 2026</span><span>Hecho para conversar.</span></div></aside>
        </div>
      )}

      {reportOpen && <div className="modal-backdrop" role="presentation" onClick={() => setReportOpen(false)}><section className="report-modal" role="dialog" aria-modal="true" aria-labelledby="report-title" onClick={e => e.stopPropagation()}><button className="modal-close" onClick={() => setReportOpen(false)} aria-label="Cerrar">×</button><div className="report-symbol">⚑</div><h2 id="report-title">Reportar conversación</h2><p>Cuéntanos qué pasó. Al enviar el reporte, la conversación terminará.</p><label htmlFor="report-reason">Motivo</label><select id="report-reason" value={reportReason} onChange={e => setReportReason(e.target.value)}><option>Acoso o insultos</option><option>Contenido sexual explícito</option><option>Amenazas o peligro</option><option>Spam o intentos de estafa</option><option>Otro</option></select><button className="primary-button full" onClick={reportUser}>Enviar reporte y salir</button><p className="fine-print">Esta versión inicial no conserva evidencia del chat. El reporte básico necesita un sistema de moderación antes del lanzamiento público.</p></section></div>}
      <footer className="mobile-footer"><span>entre<span className="brand-light">dos</span> · Conversa con respeto</span><a href="#reglas">Reglas de convivencia</a></footer>
    </main>
  );
}
