import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'EntreDos — conversaciones sin presión',
  description: 'Conoce a alguien nuevo. Una conversación a la vez.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es"><body>{children}</body></html>;
}
